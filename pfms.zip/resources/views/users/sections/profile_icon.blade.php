<a href="#" data-bs-toggle="modal" data-bs-target="#profileModal">
    <i class="fas fa-user-alt text-light fa-2x"></i>
</a>
