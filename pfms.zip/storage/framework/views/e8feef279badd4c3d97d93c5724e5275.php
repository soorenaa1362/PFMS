<?php $__env->startSection('title'); ?>
    لیست درآمد ها
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-3 p-2">
        <div class="row d-flex justify-content-center">
            <div class="col-12 col-md-8">
                <div class="card shadow p-2 mb-5 bg-body">

                    <div class="card-header text-center text-light bg-primary p-3 m-2"
                        style="border-radius: 15px;">
                        <div class="d-flex justify-content-between">

                            <?php echo $__env->make('users.sections.profile_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <?php if($card->alias === null): ?>
                                <h6 class="mt-2">لیست درآمدهای کارت : <?php echo e($card->name); ?></h6>
                            <?php else: ?>
                                <h6 class="mt-2">لیست درآمدهای کارت : <?php echo e($card->name); ?> (<?php echo e($card->alias); ?>)</h6>
                            <?php endif; ?>

                            <?php echo $__env->make('users.sections.logout_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </div>
                    </div>
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success text-center" style="margin-bottom: 0 !important">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card-body">

                        <h6 class="text-center text-light p-3 bg-secondary"
                            style="border-radius: 10px;">
                            درآمد کل : <?php echo e(number_format($totalIncome)); ?> تومان
                        </h6>
                        <div class="d-grid gap-2 m-2">
                            <a class="btn btn-success" href="<?php echo e(route('users.cards.incomes.create', $card->id)); ?>"
                                style="border-radius: 15px;">
                                <i class="fa fa-plus"></i>
                                درآمد جدید
                            </a>
                        </div>
                        <hr>
                        <table class="table table-bordered table-striped text-center">
                            <thead>
                                <tr>
                                    <th>تاریخ</th>
                                    <th>عنوان</th>
                                    <th>مبلغ</th>
                                    <th>دسته بندی</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th>
                                            <a href="<?php echo e(route('users.incomes.show', $income->id)); ?>">
                                                <?php echo e($income->getDateJalali()); ?>

                                            </a>
                                        </th>
                                        <th>
                                            <a href="<?php echo e(route('users.incomes.show', $income->id)); ?>">
                                                <?php echo e($income->title); ?>

                                            </a>
                                        </th>
                                        <th>
                                            <a href="<?php echo e(route('users.incomes.show', $income->id)); ?>">
                                                <?php echo e(number_format($income->amount)); ?> تومان
                                            </a>
                                        </th>
                                        <th>
                                            <a href="<?php echo e(route('users.incomes.show', $income->id)); ?>">
                                                <?php echo e($income->category->title); ?>

                                            </a>
                                        </th>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>

                        <?php echo e($incomes->links()); ?>


                        <?php echo $__env->make('users.sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div> <!-- card body -->

                </div> <!-- card -->
            </div> <!-- col 12 -->
        </div> <!-- row -->
    </div> <!-- container -->

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/soorenaa/Program/Company/GitProjects/1402/Git Projects/PFMS/resources/views/users/cards/incomes/index.blade.php ENDPATH**/ ?>