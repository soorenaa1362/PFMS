<?php $__env->startSection('title'); ?>
    لیست تراکنش ها
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-3 p-2">
        <div class="row d-flex justify-content-center">
            <div class="col-12 col-md-8">
                <div class="card shadow p-2 mb-5 bg-body">
                    <div class="d-flex justify-content-end">
                        <a href="<?php echo e(route('users.cards.show', [$card->id])); ?>" class="text-dark p-1">
                            <i class="fa fa-hand-o-left fa-2x"></i>
                        </a>
                    </div>
                    <div class="card-header text-center text-light bg-primary p-3 m-1"
                        style="border-radius: 15px;">
                        <div class="d-flex justify-content-between">

                            <?php echo $__env->make('users.sections.profile_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <h6 class="mt-2">
                                <?php if($card->alias === null): ?>
                                    لیست تراکنش های کارت : <?php echo e($card->name); ?>

                                <?php else: ?>
                                    لیست تراکنش های کارت : <?php echo e($card->name); ?> (<?php echo e($card->alias); ?>)
                                <?php endif; ?>
                            </h6>

                            <?php echo $__env->make('users.sections.logout_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </div>
                    </div>
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success text-center" style="margin-bottom: 0 !important">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card-body">

                        <?php if(blank($incomes)): ?>
                            <h6 class="text-center bg-success p-2 text-light">
                                هنوز هیچ درآمدی ثبت نشده است.
                            </h6>
                        <?php else: ?>
                            <div class="d-grid gap-2 mt-2">
                                <h6 class="text-center text-light p-2 bg-success"
                                    style="border-radius: 10px;">
                                    <i class="fas fa-donate"></i>
                                    لیست درآمدها
                                </h6>
                            </div>
                            <table class="table table-bordered table-striped text-center">
                                <thead>
                                    <tr>
                                        <th>تاریخ</th>
                                        <th>عنوان</th>
                                        <th>مبلغ (تومان)</th>
                                        <th>دسته بندی</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th>
                                                <a href="<?php echo e(route('users.incomes.show', [$income->id])); ?>">
                                                    <?php echo e($income->getDateJalali()); ?>

                                                </a>
                                            </th>
                                            <th>
                                                <a href="<?php echo e(route('users.incomes.show', [$income->id])); ?>">
                                                    <?php echo e($income->title); ?>

                                                </a>
                                            </th>
                                            <th>
                                                <a href="<?php echo e(route('users.incomes.show', [$income->id])); ?>">
                                                    <?php echo e(number_format($income->amount)); ?>

                                                </a>
                                            </th>
                                            <th>
                                                <a href="<?php echo e(route('users.incomes.show', [$income->id])); ?>">
                                                    <?php echo e($income->category->title); ?>

                                                </a>
                                            </th>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                            <?php echo e($incomes->links()); ?>


                        <?php endif; ?>

                        <?php if(blank($costs)): ?>
                            <h6 class="text-center bg-success p-2 text-light">
                                هنوز هیچ خرجکردی ثبت نشده است.
                            </h6>
                        <?php else: ?>
                            <div class="d-grid gap-2 mt-2">
                                <h6 class="text-center text-light p-2 bg-danger"
                                    style="border-radius: 10px;">
                                    <i class="fas fa-hand-holding-usd"></i>
                                    لیست خرجکردها
                                </h6>
                            </div>
                            <table class="table table-bordered table-striped text-center">
                                <thead>
                                    <tr>
                                        <th>تاریخ</th>
                                        <th>عنوان</th>
                                        <th>مبلغ (تومان)</th>
                                        <th>دسته بندی</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th>
                                                <a href="<?php echo e(route('users.costs.show', [$cost->id])); ?>">
                                                    <?php echo e($cost->getDateJalali()); ?>

                                                </a>
                                            </th>
                                            <th>
                                                <a href="<?php echo e(route('users.costs.show', [$cost->id])); ?>">
                                                    <?php echo e($cost->title); ?>

                                                </a>
                                            </th>
                                            <th>
                                                <a href="<?php echo e(route('users.costs.show', [$cost->id])); ?>">
                                                    <?php echo e(number_format($cost->amount)); ?>

                                                </a>
                                            </th>
                                            <th>
                                                <a href="<?php echo e(route('users.costs.show', [$cost->id])); ?>">
                                                    <?php echo e($cost->category->title); ?>

                                                </a>
                                            </th>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                            <?php echo e($costs->links()); ?>


                        <?php endif; ?>

                        <?php echo $__env->make('users.sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div> <!-- card body -->
                </div> <!-- card -->
            </div> <!-- col 12 -->
        </div> <!-- row -->
    </div> <!-- container -->

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/soorenaa/Program/Company/GitProjects/1402/Git Projects/PFMS/resources/views/users/cards/transactions/index.blade.php ENDPATH**/ ?>