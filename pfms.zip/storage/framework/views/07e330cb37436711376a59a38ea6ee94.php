<?php $__env->startSection('title'); ?>
    لیست خرجکردها
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-3 p-2">
        <div class="row d-flex justify-content-center">
            <div class="col-12 col-md-8">
                <div class="card shadow p-2 mb-5 bg-body">

                    <div class="card-header text-center text-light bg-primary p-3 m-2"
                        style="border-radius: 15px;">
                        <div class="d-flex justify-content-between">

                            <?php echo $__env->make('users.sections.profile_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <h6 class="mt-2">لیست خرجکردها</h6>

                            <?php echo $__env->make('users.sections.logout_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </div>
                    </div>
                    <?php if(Session::has('success')): ?>
                        <div class="alert alert-success text-center" style="margin-bottom: 0 !important">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <?php if( count($costCategories) == 0 ): ?>
                            <div class="d-grid gap-2 mt-2">
                                <h6 class="text-center">
                                    برای ذخیره ی خرجکردها ابتدا باید دسته های خرجکردی
                                    در سیستم ثبت نمایید.
                                </h6>
                                <a href="<?php echo e(route('users.categories.costs.create')); ?>" class="btn btn-success"
                                    style="border-radius: 15px;">
                                    ثبت دسته های خرجکرد
                                </a>
                            </div>
                        <?php else: ?>
                            <?php if(blank($costs)): ?>
                                <div class="d-grid gap-2 mt-2">
                                    <h6 class="text-center">
                                        هنوز هیچ خرجکردی در سیستم ثبت نکرده اید.
                                    </h6>
                                    <a href="<?php echo e(route('users.costs.create')); ?>" class="btn btn-success"
                                        style="border-radius: 15px;">
                                        ثبت خرجکرد
                                    </a>
                                </div>
                            <?php else: ?>
                                <h6 class="text-center text-light p-3 bg-secondary"
                                    style="border-radius: 10px;">
                                    خرجکرد کل : <?php echo e(number_format($totalCost)); ?> تومان
                                </h6>
                                <div class="d-grid gap-2 m-2">
                                    <a class="btn btn-success" href="<?php echo e(route('users.costs.create')); ?>"
                                        style="border-radius: 15px;">
                                        <i class="fa fa-plus"></i>
                                        خرجکرد جدید
                                    </a>
                                </div>
                                <hr>
                                <table class="table table-bordered table-striped text-center">
                                    <thead>
                                        <tr>
                                            <th>تاریخ</th>
                                            <th>عنوان</th>
                                            <th>مبلغ</th>
                                            <th>کارت بانکی</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th>
                                                    <a href="<?php echo e(route('users.costs.show', $cost->id)); ?>">
                                                        <?php echo e($cost->getDateJalali()); ?>

                                                    </a>
                                                </th>
                                                <th>
                                                    <a href="<?php echo e(route('users.costs.show', $cost->id)); ?>">
                                                        <?php echo e($cost->title); ?>

                                                    </a>
                                                </th>
                                                <th>
                                                    <a href="<?php echo e(route('users.costs.show', $cost->id)); ?>">
                                                        <?php echo e(number_format($cost->amount)); ?> تومان
                                                    </a>
                                                </th>
                                                <th>
                                                    <a href="<?php echo e(route('users.costs.show', $cost->id)); ?>">
                                                        <?php echo e($cost->card->name); ?>

                                                    </a>
                                                </th>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                                <?php echo e($costs->links()); ?>


                            <?php endif; ?>
                        <?php endif; ?>

                        <?php echo $__env->make('users.sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div> <!-- card body -->

                </div> <!-- card -->
            </div> <!-- col 12 -->
        </div> <!-- row -->
    </div> <!-- container -->

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/soorenaa/Program/Company/GitProjects/1402/Git Projects/PFMS/resources/views/users/costs/index.blade.php ENDPATH**/ ?>