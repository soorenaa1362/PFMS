<a href="#" data-bs-toggle="modal" data-bs-target="#profileModal">
    <i class="fas fa-user-alt text-light fa-2x"></i>
</a>
<?php /**PATH /media/soorenaa/Program/Company/GitProjects/1402/Git Projects/PFMS/resources/views/users/sections/profile_icon.blade.php ENDPATH**/ ?>