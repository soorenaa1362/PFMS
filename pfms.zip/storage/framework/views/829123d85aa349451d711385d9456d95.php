<?php $__env->startSection('title'); ?>
    ثبت تراکنش
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-3 p-2">
        <div class="row d-flex justify-content-center">
            <div class="col-12 col-md-8">
                <div class="card shadow p-2 mb-5 bg-body">
                    <div class="card-header text-center text-light bg-primary p-3 m-2"
                        style="border-radius: 15px;">
                        <div class="d-flex justify-content-between">

                            <?php echo $__env->make('users.sections.profile_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <h6 class="mt-2">گزارشات</h6>

                            <?php echo $__env->make('users.sections.logout_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </div>
                    </div>
                    <div class="card-body">

                        <div class="d-flex justify-content-around">

                            <div>
                                <a href="<?php echo e(route('users.reports.incomes')); ?>"
                                    class="text-center text-success d-grid gap-2">
                                    <i class="fas fa-donate text-success fa-4x"></i>
                                    <span style="font-size: 15px;">گزارش درآمدها</span>
                                </a>
                            </div>
                            <div>
                                <a href="" class="text-center text-danger d-grid gap-2">
                                    <i class="fas fa-hand-holding-usd text-danger fa-4x"></i>
                                    <span style="font-size: 15px;">گزارش خرجکردها</span>
                                </a>
                            </div>

                        </div>
                        <br>
                        <div class="d-flex justify-content-around">

                            <div>
                                <a href="" class="text-center text-secondary d-grid gap-2">
                                    <i class="far fa-trash-alt text-secondary fa-4x"></i>
                                    <span style="font-size: 15px;">تراکنش های حذف شده</span>
                                </a>
                            </div>

                        </div>

                        <?php echo $__env->make('users.sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div> <!-- card body -->
                </div> <!-- card -->
            </div> <!-- col 12 -->
        </div> <!-- row -->
    </div> <!-- container -->

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/soorenaa/Program/Company/GitProjects/1402/Git Projects/PFMS/resources/views/users/reports/index.blade.php ENDPATH**/ ?>