<?php $__env->startSection('title'); ?>
    نمایش جزییات خرجکرد
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-3 p-4">
        <div class="row d-flex justify-content-center">
            <div class="col-12 col-md-8">
                <div class="card shadow p-2 mb-5 bg-body">
                    <div class="card-header text-center text-light bg-primary p-3 m-1"
                        style="border-radius: 15px;">
                        <div class="d-flex justify-content-between">

                            <?php echo $__env->make('users.sections.profile_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <h6 class="mt-2">
                                نمایش جزییات خرجکرد
                            </h6>

                            <?php echo $__env->make('users.sections.logout_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </div>
                    </div>
                    <div class="card-body">

                        <div class="row">
                            <div class="col-md-6 mb-2">
                                عنوان : <?php echo e($cost->title); ?>

                            </div>
                            <div class="col-md-6 mb-2">
                                تاریخ : <?php echo e($cost->getDateJalali()); ?>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-2">
                                کارت : <?php echo e($cost->card->name); ?>

                            </div>
                            <div class="col-md-6 mb-2">
                                مبلغ : <?php echo e(number_format($cost->amount)); ?> تومان
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-2">
                                <?php if( $cost->category->parent == null ): ?>
                                    دسته بندی : <?php echo e($cost->category->title); ?>

                                <?php else: ?>
                                    دسته بندی : <?php echo e($cost->category->title); ?> (<?php echo e($cost->category->parent->title); ?>)
                                <?php endif; ?>
                            </div>
                            <?php if($cost->description === null): ?>

                            <?php else: ?>
                            <div class="col-md-6 mb-8">
                                    توضیحات : <br> <?php echo e($cost->description); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <hr>

                        <div class="d-grid gap-2 col-12 mx-auto">
                            <a href="<?php echo e(route('users.costs.edit', $cost->id)); ?>"
                                class="btn btn-warning"
                                style="border-radius: 15px;">
                                <i class="fas fa-edit"></i>
                                ویرایش اطلاعات
                            </a>
                            <a href="<?php echo e(route('users.costs.delete', $cost->id)); ?>"
                                style="border-radius: 15px;"
                                class="btn btn-danger"
                                onclick="return confirm('آیا میخواهید این خرجکرد را حذف کنید؟')">
                                <i class="fas fa-trash-alt"></i>
                                حذف
                            </a>
                        </div>

                        <?php echo $__env->make('users.sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div> <!-- card body -->
                </div> <!-- card -->
            </div> <!-- col 12 -->
        </div> <!-- row -->
    </div> <!-- container -->

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/soorenaa/Program/Company/GitProjects/1402/Git Projects/PFMS/resources/views/users/costs/show.blade.php ENDPATH**/ ?>