<?php $__env->startSection('title'); ?>
    ثبت تراکنش
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-3 p-2">
        <div class="row d-flex justify-content-center">
            <div class="col-12 col-md-8">
                <div class="card shadow p-2 mb-5 bg-body">
                    <div class="d-flex justify-content-end">
                        <a href="<?php echo e(route('users.reports.select')); ?>" class="text-dark p-1">
                            <i class="fa fa-hand-o-left fa-2x"></i>
                        </a>
                    </div>
                    <div class="card-header text-center text-light bg-primary p-3 m-2"
                        style="border-radius: 15px;">
                        <div class="d-flex justify-content-between">

                            <?php echo $__env->make('users.sections.profile_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <h6 class="mt-2">گزارش درآمدها</h6>

                            <?php echo $__env->make('users.sections.logout_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </div>
                    </div>
                    <div class="card-body">

                        <div class="d-flex justify-content-around">

                            <div>
                                <a href="<?php echo e(route('users.reports.incomes.day')); ?>"
                                    class="text-center text-success d-grid gap-2">
                                    <i class="far fa-file-alt text-success fa-4x"></i>
                                    <span style="font-size: 15px;">گزارش روزانه</span>
                                </a>
                            </div>
                            <div>
                                <a href="<?php echo e(route('users.reports.incomes.week')); ?>"
                                    class="text-center text-info d-grid gap-2">
                                    <i class="far fa-file-alt text-info fa-4x"></i>
                                    <span style="font-size: 15px;">گزارش هفتگی</span>
                                </a>
                            </div>
                            <div>
                                <a href="<?php echo e(route('users.reports.incomes.month')); ?>"
                                    class="text-center text-dark d-grid gap-2">
                                    <i class="far fa-file-alt text-dark fa-4x"></i>
                                    <span style="font-size: 15px;">گزارش ماهانه</span>
                                </a>
                            </div>
                        </div>

                        <?php echo $__env->make('users.sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div> <!-- card body -->
                </div> <!-- card -->
            </div> <!-- col 12 -->
        </div> <!-- row -->
    </div> <!-- container -->

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/soorenaa/Program/Company/GitProjects/1402/Git Projects/PFMS/resources/views/users/reports/incomes/select.blade.php ENDPATH**/ ?>