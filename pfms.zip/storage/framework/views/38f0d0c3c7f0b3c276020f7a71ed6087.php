<?php $__env->startSection('title'); ?>
    لیست دسته بندی های درآمد
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-3 p-2">
        <div class="row d-flex justify-content-center">
            <div class="col-12 col-md-8">
                <div class="card shadow p-2 mb-5 bg-body">

                    <div class="card-header text-center text-light bg-primary p-3 m-2"
                        style="border-radius: 15px;">
                        <div class="d-flex justify-content-between">

                            <?php echo $__env->make('users.sections.profile_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <h6 class="mt-2">لیست دسته بندی های درآمد</h6>

                            <?php echo $__env->make('users.sections.logout_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </div>
                    </div>
                    <?php if(Session::has('success')): ?>
                        <div class="alert alert-success text-center">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <?php if(blank($categories)): ?>
                            <div class="d-grid gap-2 mt-2">
                                <h6 class="text-center">
                                    هنوز هیچ دسته بندی در سیستم ثبت نکرده اید.
                                </h6>
                                <a href="<?php echo e(route('users.income-categories.create')); ?>"
                                    class="btn btn-success"
                                    style="border-radius: 15px;">
                                    ثبت اطلاعات دسته بندی درآمد
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="d-grid gap-2 m-2">
                                <a class="btn btn-success" href="<?php echo e(route('users.income-categories.create')); ?>"
                                    style="border-radius: 15px;">
                                    <i class="fa fa-plus"></i>
                                    دسته بندی جدید
                                </a>
                            </div>
                            <hr>
                            <table class="table table-bordered table-striped text-center">
                                <thead>
                                    <tr>
                                        <th>عنوان</th>
                                        <th>دسته ی والد</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th>
                                                <a href="">
                                                    <?php echo e($category->title); ?>

                                                </a>
                                            </th>
                                            <th>
                                                <?php if($category->parent_id == null): ?>
                                                    ----------
                                                <?php else: ?>
                                                    <a href="">
                                                        <?php echo e($category->parent->title); ?>

                                                    </a>
                                                <?php endif; ?>
                                            </th>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                            

                        <?php endif; ?>

                        <?php echo $__env->make('users.sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div> <!-- card body -->

                </div> <!-- card -->
            </div> <!-- col 12 -->
        </div> <!-- row -->
    </div> <!-- container -->

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/soorenaa/Program/Company/GitProjects/1402/Git Projects/PFMS/resources/views/users/income-categories/index.blade.php ENDPATH**/ ?>