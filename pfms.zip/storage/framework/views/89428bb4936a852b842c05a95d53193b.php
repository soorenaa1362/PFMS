<?php $__env->startSection('title'); ?>
    ثبت تراکنش
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-3 p-2">
        <div class="row d-flex justify-content-center">
            <div class="col-12 col-md-8">
                <div class="card shadow p-2 mb-5 bg-body">
                    <div class="card-header text-center text-light bg-primary p-3 m-2"
                        style="border-radius: 15px;">
                        <div class="d-flex justify-content-between">

                            <?php echo $__env->make('users.sections.profile_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <h6 class="mt-2">تراکنش های حذف شده</h6>

                            <?php echo $__env->make('users.sections.logout_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </div>
                    </div>
                    <div class="card-body">

                        <div class="d-flex justify-content-around">

                            <div>
                                <?php if( blank($incomes) ): ?>
                                    <h6 class="text-center m-2 p-2">
                                        در حال حاضر هیچ تراکنش حذف شده ای ندارید.
                                    </h6>
                                <?php else: ?>
                                    <a href="<?php echo e(route('users.deleted.incomes')); ?>"
                                        class="text-center text-success d-grid gap-2">
                                        <i class="fas fa-donate text-success fa-4x"></i>
                                        <span style="font-size: 15px;">درآمدهای حذف شده</span>
                                    </a>
                                <?php endif; ?>
                            </div>
                            

                        </div>

                        <?php echo $__env->make('users.sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div> <!-- card body -->
                </div> <!-- card -->
            </div> <!-- col 12 -->
        </div> <!-- row -->
    </div> <!-- container -->

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/soorenaa/Program/Company/GitProjects/1402/Git Projects/PFMS/resources/views/users/deleted/select.blade.php ENDPATH**/ ?>