<?php $__env->startSection('title'); ?>
    ورود
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5 p-4">
        <div class="row d-flex justify-content-center">
            <div class="col-12 col-md-6">
                <div class="card shadow p-3 mb-5 bg-body">
                    <div class="card-header bg-success text-center text-light mt-2">ورود به سیستم</div>
                    <div class="card-body">

                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="email" class="form-label">موبایل</label>
                                <input name="email" type="text" class="form-control" id="email" value="<?php echo e(old('email')); ?>" autofocus>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger">
                                        <?php echo e($message); ?>

                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label">رمز عبور</label>
                                <input name="password" type="password" class="form-control" id="password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger">
                                        <?php echo e($message); ?>

                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="d-flex justify-content-between">
                                <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                        رمز عبور خود را فراموش کرده ام.
                                    </a>
                                <?php endif; ?>
                                <button class="btn btn-success text-light" type="submit">ورود</button>
                            </div>
                            <hr>

                            <div class="d-flex justify-content-center">
                                <a href="<?php echo e(route("register")); ?>">میخواهم ثبت نام کنم.</a>
                            </div>
                        </form>
                    </div> <!-- card body -->
                </div> <!-- card -->
            </div> <!-- col 12 -->
        </div> <!-- row -->
    </div> <!-- container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/soorenaa/Program/Company/GitProjects/1402/Git Projects/PFMS/resources/views/auth/login.blade.php ENDPATH**/ ?>