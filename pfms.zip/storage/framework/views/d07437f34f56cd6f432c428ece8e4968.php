<?php $__env->startSection('title'); ?>
    ویرایش خرجکرد
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/persianDatePicker/persian-datepicker.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-3 p-4">
        <div class="row d-flex justify-content-center">
            <div class="col-12 col-md-8">
                <div class="card shadow p-2 mb-5 bg-body">
                    <div class="card-header text-center text-light bg-primary p-3 m-1"
                        style="border-radius: 15px;">
                        <div class="d-flex justify-content-between">

                            <?php echo $__env->make('users.sections.profile_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <h6 class="mt-2">ویرایش خرجکرد</h6>

                            <?php echo $__env->make('users.sections.logout_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </div>
                    </div>
                    <div class="card-body">
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-danger text-center" style="margin-bottom: 0 !important">
                                <?php echo e(Session::get('success')); ?>

                            </div>
                        <?php endif; ?>
                        <form action="<?php echo e(route('users.costs.update', $cost->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>

                            <div class="row">
                                <div class="form-group col-md-5 mt-2">
                                    <label for="title">عنوان</label>
                                    <input class="form-control" name="title" value="<?php echo e($cost->title); ?>">
                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group col-md-3 mt-2">
                                    <label for="amount">مبلغ (تومان)</label>
                                    <input class="form-control" name="amount"
                                    value="<?php echo e($cost->amount); ?>">
                                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group col-md-4 mt-2">
                                    <label for="category_id">دسته بندی</label>
                                    <select class="form-select" name="category_id" id="category_id">
                                        
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"
                                                <?php echo e($category->id === $cost->category->id ? 'selected' : ''); ?>

                                                >
                                                <?php if( $category->parent == null ): ?>
                                                    <?php echo e($category->title); ?>

                                                <?php else: ?>
                                                    <?php echo e($category->title); ?> (<?php echo e($category->parent->title); ?>)
                                                <?php endif; ?>
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group col-md-6 mt-2">
                                    <label for="card_id">کارت بانکی</label>
                                    <select class="form-select" name="card_id" id="card_id">
                                        
                                        <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($card->id); ?>"
                                                <?php echo e($card->id === $cost->card->id ? 'selected' : ''); ?>

                                                >
                                                <?php if( $card->alias === null ): ?>
                                                    <?php echo e($card->name); ?> (<?php echo e($card->current_cash); ?> تومان)
                                                <?php else: ?>
                                                    <?php echo e($card->name); ?> (<?php echo e($card->alias); ?>) (<?php echo e($card->current_cash); ?> تومان)
                                                <?php endif; ?>
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group col-md-6 mt-2">
                                    <label for="date">تاریخ</label>
                                    <input type="text" class="form-control round addpo"
                                        id="dateFake" name="dateFake" readonly required
                                        value="<?php echo e($cost->getDateJalali()); ?>">
                                    <input id="date" name="date"
                                        type="hidden" value="">
                                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" style="font-size: 14px;"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group col-md-12 mt-2">
                                    <label for="description">توضیحات</label>
                                    <textarea name="description" class="form-control">
                                        <?php echo e(old('description')); ?>

                                    </textarea>
                                </div>
                            </div>

                            <div class="d-grid gap-2 mt-2">
                                <button class="btn btn-success mt-3" type="submit"
                                    style="border-radius: 15px;">
                                    بروزرسانی
                                </button>
                            </div>

                        </form>

                        <?php echo $__env->make('users.sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div> <!-- card body -->
                </div> <!-- card -->
            </div> <!-- col 12 -->
        </div> <!-- row -->
    </div> <!-- container -->

    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/persianDatePicker/persian-date.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/persianDatePicker/persian-datepicker.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            $("#dateFake").pDatepicker({
                initialValueType: 'persian',
                initialValue: false,
                format: 'YYYY/MM/DD',
                autoClose: true,
                altField: '#date',
                altFormat: 'X', //timestarmp
            });
        });
    </script>
php <?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/soorenaa/Program/Company/GitProjects/1402/Git Projects/PFMS/resources/views/users/costs/edit.blade.php ENDPATH**/ ?>